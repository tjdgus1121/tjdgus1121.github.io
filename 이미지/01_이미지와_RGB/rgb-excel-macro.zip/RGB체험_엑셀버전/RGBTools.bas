Attribute VB_Name = "RGBTools"
Option Explicit

Private Const RGB_SIZE As Long = 150

' ==========================
' Ribbon callbacks
' ==========================
Public Sub RGB_GetRibbonImage(control As Object, ByRef returnedVal)
    Dim iconPath As String

    iconPath = ThisWorkbook.Path & Application.PathSeparator & _
               "icons" & Application.PathSeparator

    Select Case control.Id
        Case "btnAdd"
            iconPath = iconPath & "add.bmp"
        Case "btnSubtract"
            iconPath = iconPath & "sub.bmp"
        Case "btnMultiply"
            iconPath = iconPath & "mul.bmp"
        Case "btnDivide"
            iconPath = iconPath & "div.bmp"
        Case "btnClearCanvas"
            iconPath = iconPath & "clear.bmp"
        Case "btnShowAlpha"
            iconPath = iconPath & "alpha_show.bmp"
        Case "btnHideAlpha"
            iconPath = iconPath & "alpha_hide.bmp"
        Case "btnSetAlpha"
            iconPath = iconPath & "alpha_set.bmp"
        Case Else
            Set returnedVal = Nothing
            Exit Sub
    End Select

    If Dir$(iconPath) <> "" Then
        Set returnedVal = LoadPicture(iconPath)
    Else
        Set returnedVal = Nothing
    End If
End Sub

Public Sub RGB_Ribbon_MakeImage(control As Object)
    RGB_MakeImage
End Sub

Public Sub RGB_Ribbon_Add(control As Object)
    RGB_Add
End Sub

Public Sub RGB_Ribbon_Subtract(control As Object)
    RGB_Subtract
End Sub

Public Sub RGB_Ribbon_Multiply(control As Object)
    RGB_Multiply
End Sub

Public Sub RGB_Ribbon_Divide(control As Object)
    RGB_Divide
End Sub

Public Sub RGB_Ribbon_ClearCanvas(control As Object)
    RGB_ClearCanvas
End Sub

Public Sub RGB_Ribbon_ShowAlpha(control As Object)
    RGB_ShowAlphaSheet
End Sub

Public Sub RGB_Ribbon_HideAlpha(control As Object)
    RGB_HideAlphaSheet
End Sub

Public Sub RGB_Ribbon_SetAlpha(control As Object)
    RGB_SetAlphaForSelection
End Sub

Public Sub RGB_Ribbon_Help(control As Object)
    RGB_Help
End Sub

' ==========================
' RGB image generation
' ==========================
Public Sub RGB_MakeImage()
    Const H As Long = RGB_SIZE
    Const W As Long = RGB_SIZE
    Const PIC_LEFT As Double = 15
    Const PIC_TOP As Double = 45
    Const PIC_SIZE As Double = 520
    Const PIC_GAP As Double = 25

    Dim rWs As Worksheet, gWs As Worksheet, bWs As Worksheet, outWs As Worksheet
    Dim rData As Variant, gData As Variant, bData As Variant, aData As Variant
    Dim pngPath As String
    Dim shp As Shape
    Dim pic As Object
    Dim prevShp As Shape
    Dim oldCalc As XlCalculation
    Dim stage As String
    Dim insertErr As String
    Dim hadPrevious As Boolean
    Dim beforeLeft As Double

    On Error GoTo EH

    stage = "��Ʈ Ȯ��"
    Set rWs = ThisWorkbook.Worksheets("R")
    Set gWs = ThisWorkbook.Worksheets("G")
    Set bWs = ThisWorkbook.Worksheets("B")
    Set outWs = ThisWorkbook.Worksheets("Canvas")

    stage = "RGBA ������ �б�"
    rData = rWs.Range("A1").Resize(H, W).Value2
    gData = gWs.Range("A1").Resize(H, W).Value2
    bData = bWs.Range("A1").Resize(H, W).Value2
    aData = RGB_GetAlphaData(H, W)

    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    stage = "PNG �̹��� ����"
    pngPath = Environ$("TEMP") & "\AI_Math_RGBA_" & _
              Format$(Now, "yyyymmdd_hhnnss") & "_" & _
              Format$(CLng(Timer * 1000) Mod 1000000, "000000") & ".png"
    RGB_WriteTransparentPNG pngPath, rData, gData, bData, aData, H, W

    If Dir$(pngPath) = "" Then
        Err.Raise vbObjectError + 301, , "�ӽ� PNG ������ ������ ���߽��ϴ�."
    End If

    stage = "���� �̹��� ����"
    beforeLeft = PIC_LEFT + PIC_SIZE + PIC_GAP
    hadPrevious = False

    On Error Resume Next
    outWs.Shapes("RGB_PREVIEW_NEW").Delete
    outWs.Shapes("RGB_BEFORE").Delete
    outWs.Shapes("RGB_PREVIEW_OLD").Delete
    outWs.Shapes("RGB_LABEL_BEFORE").Delete
    outWs.Shapes("RGB_LABEL_AFTER").Delete
    Set prevShp = outWs.Shapes("RGB_PREVIEW")
    On Error GoTo EH

    If Not prevShp Is Nothing Then
        hadPrevious = True
        prevShp.Name = "RGB_BEFORE"
        prevShp.Left = beforeLeft
        prevShp.Top = PIC_TOP
        prevShp.Width = PIC_SIZE
        prevShp.Height = PIC_SIZE
        prevShp.LockAspectRatio = msoFalse
    End If

    stage = "�̹��� ����"
    Set shp = Nothing
    Set pic = Nothing

    On Error Resume Next
    Set shp = outWs.Shapes.AddPicture( _
        Filename:=pngPath, _
        LinkToFile:=False, _
        SaveWithDocument:=True, _
        Left:=PIC_LEFT, _
        Top:=PIC_TOP, _
        Width:=PIC_SIZE, _
        Height:=PIC_SIZE)

    If shp Is Nothing Then
        insertErr = Err.Description
        Err.Clear

        Set pic = outWs.Pictures.Insert(pngPath)
        If Not pic Is Nothing Then
            pic.Left = PIC_LEFT
            pic.Top = PIC_TOP
            pic.Width = PIC_SIZE
            pic.Height = PIC_SIZE
            pic.Name = "RGB_PREVIEW_NEW"
        End If
    Else
        shp.Name = "RGB_PREVIEW_NEW"
        shp.LockAspectRatio = msoFalse
    End If
    On Error GoTo EH

    If shp Is Nothing And pic Is Nothing Then
        Err.Raise vbObjectError + 303, , _
            "Excel�� �̹����� �������� ���߽��ϴ�." & vbCrLf & insertErr
    End If

    If Not shp Is Nothing Then
        shp.Name = "RGB_PREVIEW"
    ElseIf Not pic Is Nothing Then
        pic.Name = "RGB_PREVIEW"
    End If

    RGB_AddComparisonLabel outWs, "RGB_LABEL_AFTER", "��", PIC_LEFT, 10
    If hadPrevious Then
        RGB_AddComparisonLabel outWs, "RGB_LABEL_BEFORE", "��", beforeLeft, 10
    End If

    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    outWs.Activate
    outWs.Range("A1").Select

    On Error Resume Next
    ActiveWindow.Zoom = 75
    ActiveWindow.ScrollRow = 1
    ActiveWindow.ScrollColumn = 1
    On Error GoTo 0

    If hadPrevious Then
        MsgBox "RGBA ���� PNG�� ����������ϴ�!" & vbCrLf & _
               "������ ��, �������� ���Դϴ�." & vbCrLf & _
               "Canvas ��Ʈ�� Ȯ���ϼ���.", vbInformation
    Else
        MsgBox "RGBA ���� PNG�� ����������ϴ�!" & vbCrLf & _
               "���ʿ� ����� ǥ�õǾ����ϴ�." & vbCrLf & _
               "Canvas ��Ʈ�� Ȯ���ϼ���.", vbInformation
    End If
    Exit Sub

EH:
    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    On Error GoTo 0

    MsgBox "�̹��� ���� �� ������ �߻��߽��ϴ�." & vbCrLf & _
           "�ܰ�: " & stage & vbCrLf & _
           "����: " & Err.Description, vbExclamation
End Sub

Private Function RGB_GetAlphaData(ByVal H As Long, ByVal W As Long) As Variant
    Dim aWs As Worksheet
    Dim aData As Variant
    Dim y As Long, x As Long

    On Error Resume Next
    Set aWs = ThisWorkbook.Worksheets("A")
    On Error GoTo 0

    If aWs Is Nothing Then
        ReDim aData(1 To H, 1 To W)
        For y = 1 To H
            For x = 1 To W
                aData(y, x) = 255
            Next x
        Next y
    Else
        aData = aWs.Range("A1").Resize(H, W).Value2
    End If

    RGB_GetAlphaData = aData
End Function

Private Sub RGB_WriteTransparentPNG(ByVal filePath As String, _
                                    ByRef rData As Variant, _
                                    ByRef gData As Variant, _
                                    ByRef bData As Variant, _
                                    ByRef aData As Variant, _
                                    ByVal H As Long, _
                                    ByVal W As Long)

    Dim rawPath As String
    Dim psPath As String
    Dim logPath As String
    Dim pixels() As Byte
    Dim x As Long, y As Long, p As Long
    Dim rr As Long, gg As Long, bb As Long, aa As Long
    Dim f As Integer
    Dim shell As Object
    Dim cmd As String
    Dim exitCode As Long
    Dim script As String
    Dim logText As String

    rawPath = Environ$("TEMP") & "\AI_Math_RGBA_" & _
              Format$(Now, "yyyymmdd_hhnnss") & "_" & _
              Format$(CLng(Timer * 1000) Mod 1000000, "000000") & ".raw"
    psPath = Replace$(rawPath, ".raw", ".ps1")
    logPath = Replace$(rawPath, ".raw", ".log")

    ReDim pixels(0 To H * W * 4 - 1) As Byte

    p = 0
    For y = 1 To H
        For x = 1 To W
            rr = RGB_ClampByte(rData(y, x))
            gg = RGB_ClampByte(gData(y, x))
            bb = RGB_ClampByte(bData(y, x))
            aa = RGB_ClampAlpha(aData(y, x))

            pixels(p) = CByte(rr)
            pixels(p + 1) = CByte(gg)
            pixels(p + 2) = CByte(bb)
            pixels(p + 3) = CByte(aa)
            p = p + 4
        Next x
    Next y

    On Error Resume Next
    If Dir$(filePath) <> "" Then Kill filePath
    If Dir$(rawPath) <> "" Then Kill rawPath
    If Dir$(psPath) <> "" Then Kill psPath
    If Dir$(logPath) <> "" Then Kill logPath
    On Error GoTo 0

    f = FreeFile
    Open rawPath For Binary Access Write As #f
    Put #f, , pixels
    Close #f

    script = _
        "param([string]$RawPath,[string]$OutPath,[int]$Width,[int]$Height)" & vbCrLf & _
        "$ErrorActionPreference = 'Stop'" & vbCrLf & _
        "Add-Type -AssemblyName System.Drawing" & vbCrLf & _
        "$bytes = [System.IO.File]::ReadAllBytes($RawPath)" & vbCrLf & _
        "$expected = $Width * $Height * 4" & vbCrLf & _
        "if ($bytes.Length -lt $expected) { throw 'RGBA raw data size is invalid.' }" & vbCrLf & _
        "$bmp = New-Object System.Drawing.Bitmap($Width, $Height, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)" & vbCrLf & _
        "$i = 0" & vbCrLf & _
        "for ($y = 0; $y -lt $Height; $y++) {" & vbCrLf & _
        "  for ($x = 0; $x -lt $Width; $x++) {" & vbCrLf & _
        "    $r = [int]$bytes[$i]" & vbCrLf & _
        "    $g = [int]$bytes[$i + 1]" & vbCrLf & _
        "    $b = [int]$bytes[$i + 2]" & vbCrLf & _
        "    $a = [int]$bytes[$i + 3]" & vbCrLf & _
        "    $color = [System.Drawing.Color]::FromArgb($a, $r, $g, $b)" & vbCrLf & _
        "    $bmp.SetPixel($x, $y, $color)" & vbCrLf & _
        "    $i += 4" & vbCrLf & _
        "  }" & vbCrLf & _
        "}" & vbCrLf & _
        "$bmp.Save($OutPath, [System.Drawing.Imaging.ImageFormat]::Png)" & vbCrLf & _
        "$bmp.Dispose()"

    f = FreeFile
    Open psPath For Output As #f
    Print #f, script
    Close #f

    Set shell = CreateObject("WScript.Shell")
    cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File " & _
          RGB_QuotePSArg(psPath) & " -RawPath " & RGB_QuotePSArg(rawPath) & _
          " -OutPath " & RGB_QuotePSArg(filePath) & _
          " -Width " & CStr(W) & " -Height " & CStr(H) & _
          " > " & RGB_QuotePSArg(logPath) & " 2>&1"

    exitCode = shell.Run(cmd, 0, True)
    Set shell = Nothing

    If exitCode <> 0 Or Dir$(filePath) = "" Then
        logText = RGB_ReadTextFile(logPath)
        If Len(logText) > 0 Then
            Err.Raise vbObjectError + 305, , _
                "���� PNG ������ �����߽��ϴ�." & vbCrLf & logText
        Else
            Err.Raise vbObjectError + 305, , _
                "���� PNG ������ �����߽��ϴ�. (PowerShell ���� �ڵ�: " & exitCode & ")"
        End If
    End If

    On Error Resume Next
    If Dir$(rawPath) <> "" Then Kill rawPath
    If Dir$(psPath) <> "" Then Kill psPath
    If Dir$(logPath) <> "" Then Kill logPath
    On Error GoTo 0
End Sub

Private Function RGB_ClampAlpha(ByVal v As Variant) As Long
    Dim n As Double

    If Len(v) = 0 Then
        RGB_ClampAlpha = 255
        Exit Function
    End If

    If IsNumeric(v) Then
        n = CDbl(v)
    Else
        RGB_ClampAlpha = 255
        Exit Function
    End If

    If n < 0 Then n = 0
    If n > 255 Then n = 255

    RGB_ClampAlpha = CLng(Int(n + 0.5))
End Function

Private Function RGB_QuotePSArg(ByVal s As String) As String
    RGB_QuotePSArg = Chr$(34) & Replace$(s, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function

Private Function RGB_ReadTextFile(ByVal filePath As String) As String
    Dim f As Integer
    Dim t As String

    On Error GoTo EH
    If Dir$(filePath) = "" Then Exit Function

    f = FreeFile
    Open filePath For Input As #f
    t = Input$(LOF(f), #f)
    Close #f

    RGB_ReadTextFile = t
    Exit Function
EH:
    On Error Resume Next
    If f <> 0 Then Close #f
    RGB_ReadTextFile = ""
End Function

Private Sub RGB_AddComparisonLabel(ws As Worksheet, shapeName As String, caption As String, _
                                   leftPos As Double, topPos As Double)
    Dim s As Shape

    On Error Resume Next
    ws.Shapes(shapeName).Delete
    On Error GoTo 0

    Set s = ws.Shapes.AddShape(msoShapeRoundedRectangle, leftPos, topPos, 55, 26)
    With s
        .Name = shapeName
        .Fill.ForeColor.RGB = RGB(41, 84, 145)
        .Line.Visible = msoFalse
        .TextFrame.Characters.Text = caption
        .TextFrame.Characters.Font.Bold = True
        .TextFrame.Characters.Font.Size = 12
        .TextFrame.Characters.Font.Color = vbWhite
        .TextFrame.HorizontalAlignment = xlHAlignCenter
        .TextFrame.VerticalAlignment = xlVAlignCenter
    End With
End Sub

Private Sub RGB_WriteBMP(ByVal filePath As String, _
                         ByRef rData As Variant, _
                         ByRef gData As Variant, _
                         ByRef bData As Variant, _
                         ByVal H As Long, _
                         ByVal W As Long)

    Dim header(0 To 53) As Byte
    Dim pixels() As Byte
    Dim rowBytes As Long
    Dim imageSize As Long
    Dim fileSize As Long
    Dim x As Long, y As Long
    Dim p As Long, destRow As Long
    Dim rr As Long, gg As Long, bb As Long
    Dim f As Integer

    rowBytes = ((W * 3 + 3) \ 4) * 4
    imageSize = rowBytes * H
    fileSize = 54 + imageSize
    ReDim pixels(0 To imageSize - 1) As Byte

    header(0) = Asc("B")
    header(1) = Asc("M")
    RGB_PutLongLE header, 2, fileSize
    RGB_PutLongLE header, 10, 54
    RGB_PutLongLE header, 14, 40
    RGB_PutLongLE header, 18, W
    RGB_PutLongLE header, 22, H
    RGB_PutIntLE header, 26, 1
    RGB_PutIntLE header, 28, 24
    RGB_PutLongLE header, 34, imageSize

    For y = 1 To H
        destRow = (H - y) * rowBytes

        For x = 1 To W
            rr = RGB_ClampByte(rData(y, x))
            gg = RGB_ClampByte(gData(y, x))
            bb = RGB_ClampByte(bData(y, x))

            p = destRow + (x - 1) * 3
            pixels(p) = CByte(bb)
            pixels(p + 1) = CByte(gg)
            pixels(p + 2) = CByte(rr)
        Next x
    Next y

    On Error Resume Next
    If Dir$(filePath) <> "" Then Kill filePath
    On Error GoTo 0

    f = FreeFile
    Open filePath For Binary Access Write As #f
    Put #f, , header
    Put #f, , pixels
    Close #f
End Sub


Private Sub RGB_PutLongLE(ByRef buf() As Byte, ByVal pos As Long, ByVal value As Long)
    buf(pos) = CByte(value And &HFF&)
    buf(pos + 1) = CByte((value \ &H100&) And &HFF&)
    buf(pos + 2) = CByte((value \ &H10000) And &HFF&)
    buf(pos + 3) = CByte((value \ &H1000000) And &HFF&)
End Sub


Private Sub RGB_PutIntLE(ByRef buf() As Byte, ByVal pos As Long, ByVal value As Long)
    buf(pos) = CByte(value And &HFF&)
    buf(pos + 1) = CByte((value \ &H100&) And &HFF&)
End Sub


Private Function RGB_ClampByte(ByVal v As Variant) As Long
    Dim n As Double

    If IsNumeric(v) Then
        n = CDbl(v)
    Else
        n = 0
    End If

    If n < 0 Then n = 0
    If n > 255 Then n = 255

    RGB_ClampByte = CLng(Int(n + 0.5))
End Function


' ==========================
' Selected-cell operations
' ==========================
Public Sub RGB_Add()
    RGB_ApplyOperation "+"
End Sub

Public Sub RGB_Subtract()
    RGB_ApplyOperation "-"
End Sub

Public Sub RGB_Multiply()
    RGB_ApplyOperation "*"
End Sub

Public Sub RGB_Divide()
    RGB_ApplyOperation "/"
End Sub


Private Sub RGB_ApplyOperation(ByVal op As String)
    Dim inputValue As Variant
    Dim ar As Range
    Dim v As Variant
    Dim r As Long, c As Long
    Dim n As Double
    Dim oldCalc As XlCalculation
    Dim sheetName As String

    If TypeName(ActiveSheet) <> "Worksheet" Then Exit Sub

    sheetName = ActiveSheet.Name
    If sheetName <> "R" And sheetName <> "G" And sheetName <> "B" And sheetName <> "A" Then
        MsgBox "���� R, G, B, A �� �� ��Ʈ���� �ٲ� ���� �����ϼ���.", vbInformation
        Exit Sub
    End If

    If TypeName(Selection) <> "Range" Then
        MsgBox "���� �ٲ� ���� �巡���ؼ� �����ϼ���.", vbInformation
        Exit Sub
    End If

    Select Case op
        Case "+"
            inputValue = Application.InputBox( _
                Prompt:="������ ���� ���� ���� �Է��ϼ���.", _
                Title:="���ϱ�", Type:=1)
        Case "-"
            inputValue = Application.InputBox( _
                Prompt:="������ ������ �� ���� �Է��ϼ���.", _
                Title:="����", Type:=1)
        Case "*"
            inputValue = Application.InputBox( _
                Prompt:="������ ���� ���� ���� �Է��ϼ���.", _
                Title:="���ϱ�", Type:=1)
        Case "/"
            inputValue = Application.InputBox( _
                Prompt:="������ ���� ���� ���� �Է��ϼ���.", _
                Title:="������", Type:=1)
    End Select

    If VarType(inputValue) = vbBoolean And inputValue = False Then Exit Sub

    n = CDbl(inputValue)

    If op = "/" And n = 0 Then
        MsgBox "0���� ���� �� �����ϴ�.", vbExclamation
        Exit Sub
    End If

    On Error GoTo EH

    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    For Each ar In Selection.Areas
        If ar.Cells.CountLarge = 1 Then
            If ar.HasFormula Then
                ' ���� ���� �״�� �Ӵϴ�.
            ElseIf Len(ar.Value2) = 0 Then
                ar.Value2 = RGB_OperateAndClamp(0, n, op)
            ElseIf IsNumeric(ar.Value2) Then
                ar.Value2 = RGB_OperateAndClamp(CDbl(ar.Value2), n, op)
            End If
        Else
            v = ar.Value2

            For r = 1 To UBound(v, 1)
                For c = 1 To UBound(v, 2)
                    If ar.Cells(r, c).HasFormula Then
                        ' ���� ���� �״�� �Ӵϴ�.
                    ElseIf Len(v(r, c)) = 0 Then
                        v(r, c) = RGB_OperateAndClamp(0, n, op)
                    ElseIf IsNumeric(v(r, c)) Then
                        v(r, c) = RGB_OperateAndClamp(CDbl(v(r, c)), n, op)
                    End If
                Next c
            Next r

            ar.Value2 = v
        End If
    Next ar

    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    Exit Sub

EH:
    Dim errNum As Long
    Dim errDesc As String

    errNum = Err.Number
    errDesc = Err.Description

    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    On Error GoTo 0

    MsgBox "���� ���� ��� �� ������ �߻��߽��ϴ�." & vbCrLf & _
           "���� " & errNum & ": " & errDesc, vbExclamation
End Sub


Private Function RGB_OperateAndClamp(ByVal a As Double, _
                                     ByVal b As Double, _
                                     ByVal op As String) As Double
    Dim result As Double

    Select Case op
        Case "+"
            result = a + b
        Case "-"
            result = a - b
        Case "*"
            result = a * b
        Case "/"
            result = a / b
    End Select

    If result < 0 Then result = 0
    If result > 255 Then result = 255

    RGB_OperateAndClamp = result
End Function


Public Sub RGB_SetAlphaForSelection()
    Dim inputValue As Variant
    Dim aWs As Worksheet
    Dim sourceWs As Worksheet
    Dim ar As Range
    Dim alphaValue As Long
    Dim oldCalc As XlCalculation
    Dim targetRange As Range

    If TypeName(ActiveSheet) <> "Worksheet" Then Exit Sub

    If ActiveSheet.Name <> "R" And ActiveSheet.Name <> "G" And ActiveSheet.Name <> "B" And ActiveSheet.Name <> "A" Then
        MsgBox "R, G, B �Ǵ� A ��Ʈ���� ������ ������ �� ����ϼ���.", vbInformation, "RGBA - ������ ����"
        Exit Sub
    End If

    If TypeName(Selection) <> "Range" Then
        MsgBox "���� ������ �� ������ �巡���ؼ� �����ϼ���.", vbInformation, "RGBA - ������ ����"
        Exit Sub
    End If

    inputValue = Application.InputBox( _
        Prompt:="���� ������ ������ A��(0~255)�� �Է��ϼ���." & vbCrLf & _
                "0 = ���� ����, 255 = ���� ������", _
        Title:="������ ����", Type:=1)

    If VarType(inputValue) = vbBoolean And inputValue = False Then Exit Sub

    alphaValue = RGB_ClampAlpha(inputValue)
    Set aWs = RGB_EnsureAlphaSheet()
    Set sourceWs = ActiveSheet

    On Error GoTo EH
    oldCalc = Application.Calculation
    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.Calculation = xlCalculationManual

    For Each ar In Selection.Areas
        Set targetRange = aWs.Range(ar.Address)
        targetRange.Value2 = alphaValue
    Next ar

    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "���� ������ A���� " & alphaValue & " �� �����߽��ϴ�." & vbCrLf & _
           "(0=����, 255=������)", vbInformation, "RGBA - ������ ����"
    Exit Sub
EH:
    On Error Resume Next
    Application.Calculation = oldCalc
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    On Error GoTo 0

    MsgBox "������ ���� �� ������ �߻��߽��ϴ�." & vbCrLf & Err.Description, _
           vbExclamation, "RGBA - ������ ����"
End Sub

Private Function RGB_EnsureAlphaSheet() As Worksheet
    Dim ws As Worksheet

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("A")
    On Error GoTo 0

    If ws Is Nothing Then
        Application.ScreenUpdating = False
        Set ws = ThisWorkbook.Worksheets.Add(After:=ThisWorkbook.Worksheets("B"))
        ws.Name = "A"
        ws.Range("A1").Resize(RGB_SIZE, RGB_SIZE).Value2 = 255
        ws.Visible = xlSheetVeryHidden
        Application.ScreenUpdating = True
    End If

    Set RGB_EnsureAlphaSheet = ws
End Function

Public Sub RGB_ShowAlphaSheet()
    Dim ws As Worksheet

    On Error GoTo EH
    Set ws = RGB_EnsureAlphaSheet()
    ws.Visible = xlSheetVisible

    On Error Resume Next
    ws.Move After:=ThisWorkbook.Worksheets("B")
    On Error GoTo EH

    ws.Activate
    MsgBox "A ��Ʈ�� ǥ���߽��ϴ�." & vbCrLf & _
           "A ���� 0~255 ������ ����մϴ�." & vbCrLf & _
           "0�� ����, 255�� �������Դϴ�.", vbInformation, "RGBA - A ��Ʈ"
    Exit Sub

EH:
    MsgBox "A ��Ʈ�� ǥ������ ���߽��ϴ�." & vbCrLf & Err.Description, _
           vbExclamation, "RGBA - A ��Ʈ"
End Sub

Public Sub RGB_HideAlphaSheet()
    Dim ws As Worksheet

    On Error GoTo EH
    Set ws = RGB_EnsureAlphaSheet()

    If ActiveSheet.Name = ws.Name Then
        ThisWorkbook.Worksheets("R").Activate
    End If

    ws.Visible = xlSheetVeryHidden
    MsgBox "A ��Ʈ�� ������ϴ�.", vbInformation, "RGBA - A ��Ʈ"
    Exit Sub

EH:
    MsgBox "A ��Ʈ�� ������ ���߽��ϴ�." & vbCrLf & Err.Description, _
           vbExclamation, "RGBA - A ��Ʈ"
End Sub

Public Sub RGB_ClearCanvas()
    Dim ws As Worksheet

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets("Canvas")
    If Not ws Is Nothing Then
        ws.Shapes("RGB_PREVIEW").Delete
        ws.Shapes("RGB_PREVIEW_NEW").Delete
        ws.Shapes("RGB_BEFORE").Delete
        ws.Shapes("RGB_PREVIEW_OLD").Delete
        ws.Shapes("RGB_LABEL_BEFORE").Delete
        ws.Shapes("RGB_LABEL_AFTER").Delete
    End If
    On Error GoTo 0
End Sub


Public Sub RGB_Help()
    MsgBox _
        "RGB ü�� ����" & vbCrLf & vbCrLf & _
        "1. R/G/B ��Ʈ���� �ٲ� ���� �巡���մϴ�." & vbCrLf & _
        "2. RGB ü�� �ǿ��� +, -, ��, ���� �����մϴ�." & vbCrLf & _
        "3. �̹��� ����⸦ ������ Canvas ���ʿ� �� �̹����� ��Ÿ���ϴ�." & vbCrLf & _
        "4. ���� �̹����� ������ �������� �� �̹����� �̵��մϴ�." & vbCrLf & _
        "5. ��ĭ�� 0���� ���� ����մϴ�." & vbCrLf & _
        "6. ��� ����� 0~255 ������ �ڵ� ���ѵ˴ϴ�." & vbCrLf & _
        "7. ����(A) �޴����� A ��Ʈ�� ���̰ų� ���� �� �ֽ��ϴ�." & vbCrLf & _
        "8. ������ ���� ��ư���� ���� ������ A���� �� ���� �Է��� �� �ֽ��ϴ�." & vbCrLf & _
        "9. A ���� 0=����, 255=���������� PNG�� �ݿ��˴ϴ�.", _
        vbInformation, "RGB ü��"
End Sub
