﻿param(
  [switch]$Elevated,
  [string]$TargetLocalAppData = "",
  [string]$TargetDesktop = "",
  [string]$TargetUserSid = ""
)

$ErrorActionPreference = "Stop"
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.IO.Compression.FileSystem

function Info([string]$m) {
  [System.Windows.MessageBox]::Show(
    $m, "RGB 체험 설치",
    [System.Windows.MessageBoxButton]::OK,
    [System.Windows.MessageBoxImage]::Information
  ) | Out-Null
}

function Fail([string]$m) {
  [System.Windows.MessageBox]::Show(
    $m, "RGB 체험 설치 오류",
    [System.Windows.MessageBoxButton]::OK,
    [System.Windows.MessageBoxImage]::Error
  ) | Out-Null
}

function Confirm-Install() {
  $msg = "설치를 시작하면 실행 중인 모든 Excel이 강제 종료됩니다.`n`n저장하지 않은 Excel 작업 내용은 사라질 수 있습니다.`n`n그래도 실행하시겠습니까?"
  $result = [System.Windows.MessageBox]::Show(
    $msg, "RGB 체험 설치",
    [System.Windows.MessageBoxButton]::YesNo,
    [System.Windows.MessageBoxImage]::Warning
  )
  return ($result -eq [System.Windows.MessageBoxResult]::Yes)
}

function Add-RibbonXml([string]$book, [string]$uiFile) {
  $tmp = Join-Path $env:TEMP ("rgb_ribbon_" + [guid]::NewGuid().ToString())
  New-Item -ItemType Directory -Force -Path $tmp | Out-Null

  try {
    [System.IO.Compression.ZipFile]::ExtractToDirectory($book, $tmp)

    $customDir = Join-Path $tmp "customUI"
    if (Test-Path $customDir) {
      Remove-Item -Recurse -Force $customDir
    }
    New-Item -ItemType Directory -Force -Path $customDir | Out-Null
    Copy-Item -Force $uiFile (Join-Path $customDir "customUI14.xml")

    # package relationships
    $relsPath = Join-Path $tmp "_rels\.rels"
    [xml]$rels = Get-Content -LiteralPath $relsPath -Raw

    $ns = New-Object System.Xml.XmlNamespaceManager($rels.NameTable)
    $ns.AddNamespace(
      "r",
      "http://schemas.openxmlformats.org/package/2006/relationships"
    )

    $oldNodes = @(
      $rels.SelectNodes(
        "/r:Relationships/r:Relationship[contains(@Type,'relationships/ui/extensibility')]",
        $ns
      )
    )

    foreach ($old in $oldNodes) {
      [void]$rels.Relationships.RemoveChild($old)
    }

    $max = 0
    foreach ($x in $rels.Relationships.Relationship) {
      if ($x.Id -match '^rId(\d+)$') {
        if ([int]$matches[1] -gt $max) {
          $max = [int]$matches[1]
        }
      }
    }

    $new = $rels.CreateElement(
      "Relationship",
      "http://schemas.openxmlformats.org/package/2006/relationships"
    )
    $new.SetAttribute("Id", "rId" + ($max + 1))
    $new.SetAttribute(
      "Type",
      "http://schemas.microsoft.com/office/2007/relationships/ui/extensibility"
    )
    $new.SetAttribute("Target", "/customUI/customUI14.xml")
    [void]$rels.Relationships.AppendChild($new)
    $rels.Save($relsPath)

    # content types
    $ctPath = Join-Path $tmp "[Content_Types].xml"
    [xml]$ct = Get-Content -LiteralPath $ctPath -Raw

    $ctns = New-Object System.Xml.XmlNamespaceManager($ct.NameTable)
    $ctns.AddNamespace(
      "t",
      "http://schemas.openxmlformats.org/package/2006/content-types"
    )

    $oldOverride = $ct.SelectSingleNode(
      "/t:Types/t:Override[@PartName='/customUI/customUI14.xml']",
      $ctns
    )

    if ($null -ne $oldOverride) {
      [void]$ct.Types.RemoveChild($oldOverride)
    }

    $newov = $ct.CreateElement(
      "Override",
      "http://schemas.openxmlformats.org/package/2006/content-types"
    )
    $newov.SetAttribute("PartName", "/customUI/customUI14.xml")
    $newov.SetAttribute("ContentType", "application/xml")
    [void]$ct.Types.AppendChild($newov)
    $ct.Save($ctPath)

    Remove-Item -Force $book
    [System.IO.Compression.ZipFile]::CreateFromDirectory($tmp, $book)
  }
  finally {
    Remove-Item -Recurse -Force $tmp -ErrorAction SilentlyContinue
  }
}


function Test-PermissionError([System.Exception]$ex) {
  $cur = $ex
  while ($null -ne $cur) {
    if ($cur -is [System.UnauthorizedAccessException] -or
        $cur -is [System.Security.SecurityException]) {
      return $true
    }

    # 0x80070005 = E_ACCESSDENIED
    if ($cur.HResult -eq -2147024891) {
      return $true
    }

    $msg = [string]$cur.Message
    if ($msg -match '(?i)access.*denied|unauthorized|permission.*denied|액세스.*거부|권한.*없') {
      return $true
    }

    $cur = $cur.InnerException
  }
  return $false
}

function Get-CurrentSid() {
  return ([System.Security.Principal.WindowsIdentity]::GetCurrent()).User.Value
}

function Get-TargetSecurityPath([string]$officeVersion, [string]$targetSid) {
  $currentSid = Get-CurrentSid
  if ([string]::IsNullOrWhiteSpace($targetSid) -or $targetSid -eq $currentSid) {
    return "HKCU:\Software\Microsoft\Office\$officeVersion\Excel\Security"
  }

  if (-not (Get-PSDrive -Name HKU -ErrorAction SilentlyContinue)) {
    New-PSDrive -Name HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
  }
  return "HKU:\$targetSid\Software\Microsoft\Office\$officeVersion\Excel\Security"
}

function Start-ElevatedRetry([string]$scriptPath, [string]$localAppData, [string]$desktop, [string]$userSid) {
  Info "이 PC에서는 설치에 관리자 권한이 필요합니다.`n`n잠시 후 Windows 권한 확인창이 나타납니다.`n[예]를 누르면 설치를 자동으로 계속합니다."

  $argLine = '-NoProfile -ExecutionPolicy Bypass -File "{0}" -Elevated -TargetLocalAppData "{1}" -TargetDesktop "{2}" -TargetUserSid "{3}"' -f `
             $scriptPath.Replace('"','\"'), `
             $localAppData.Replace('"','\"'), `
             $desktop.Replace('"','\"'), `
             $userSid.Replace('"','\"')

  $p = Start-Process powershell.exe -Verb RunAs -ArgumentList $argLine -Wait -PassThru
  return $p.ExitCode
}


# 일반 실행에서는 콘솔 없이 GUI 확인창으로 설치 여부를 묻습니다.
# 관리자 권한 재실행(-Elevated)에서는 같은 질문을 반복하지 않습니다.
if (-not $Elevated) {
  if (-not (Confirm-Install)) {
    exit 0
  }
}

# 원래 로그인한 사용자의 설치 위치를 보존합니다.
if ([string]::IsNullOrWhiteSpace($TargetLocalAppData)) {
  $TargetLocalAppData = $env:LOCALAPPDATA
}
if ([string]::IsNullOrWhiteSpace($TargetDesktop)) {
  $TargetDesktop = [Environment]::GetFolderPath("Desktop")
}
if ([string]::IsNullOrWhiteSpace($TargetUserSid)) {
  $TargetUserSid = Get-CurrentSid
}

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcBook = Join-Path $here "RGB체험_원본.xlsm"
$srcBas  = Join-Path $here "RGBTools.bas"
$srcUI   = Join-Path $here "customUI14.xml"
$srcIcons = Join-Path $here "icons"

$destDir  = Join-Path $TargetLocalAppData "AI_Math_RGB_Ribbon"
$destBook = Join-Path $destDir "RGB체험_리본메뉴.xlsm"
$destIcons = Join-Path $destDir "icons"

$excel = $null
$wb = $null
$probe = $null
$proj = $null
$aSheet = $null
$comSec = $null
$hadAccess = $false
$oldAccess = $null

try {
  # 설치 시작 전 실행 중인 Excel 프로세스를 정리합니다.
  # 권한 때문에 종료하지 못하면 catch에서 자동으로 관리자 권한 재실행합니다.
  $excelProcesses = @(Get-Process EXCEL -ErrorAction SilentlyContinue)
  if ($excelProcesses.Count -gt 0) {
    foreach ($p in $excelProcesses) {
      Stop-Process -Id $p.Id -Force -ErrorAction Stop
    }
    Start-Sleep -Milliseconds 900
  }

  if (Get-Process EXCEL -ErrorAction SilentlyContinue) {
    throw [System.UnauthorizedAccessException]::new("실행 중인 Excel 프로세스를 일반 권한으로 종료하지 못했습니다.")
  }

  New-Item -ItemType Directory -Force -Path $destDir | Out-Null
  New-Item -ItemType Directory -Force -Path $destIcons | Out-Null
  Copy-Item -Force $srcBook $destBook
  Copy-Item -Recurse -Force (Join-Path $srcIcons "*") $destIcons
  Unblock-File -Path $destBook -ErrorAction SilentlyContinue

  $probe = New-Object -ComObject Excel.Application
  $ver = [string]$probe.Version
  $probe.Quit()
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($probe)
  $probe = $null

  # 실제 사용자의 Trusted Location은 원래 사용자 SID에 기록합니다.
  $targetSec = Get-TargetSecurityPath $ver $TargetUserSid
  $trusted = Join-Path $targetSec "Trusted Locations"
  New-Item -Force -Path $targetSec | Out-Null
  New-Item -Force -Path $trusted | Out-Null

  $loc = Join-Path $trusted "Location98"
  New-Item -Force -Path $loc | Out-Null

  $tp = $destDir
  if (-not $tp.EndsWith("\")) { $tp += "\" }

  New-ItemProperty -Path $loc -Name Path -PropertyType String -Value $tp -Force | Out-Null
  New-ItemProperty -Path $loc -Name AllowSubfolders -PropertyType DWord -Value 1 -Force | Out-Null
  New-ItemProperty -Path $loc -Name Description -PropertyType String -Value "AI Math RGB Ribbon" -Force | Out-Null

  # VBA import를 수행하는 현재 계정의 Excel에만 AccessVBOM을 잠시 허용합니다.
  $comSec = "HKCU:\Software\Microsoft\Office\$ver\Excel\Security"
  New-Item -Force -Path $comSec | Out-Null

  try {
    $oldAccess = (Get-ItemProperty -Path $comSec -Name AccessVBOM -ErrorAction Stop).AccessVBOM
    $hadAccess = $true
  } catch {}

  New-ItemProperty -Path $comSec -Name AccessVBOM -PropertyType DWord -Value 1 -Force | Out-Null

  $excel = New-Object -ComObject Excel.Application
  $excel.Visible = $false
  $excel.DisplayAlerts = $false
  $excel.AutomationSecurity = 3

  $wb = $excel.Workbooks.Open($destBook, 0, $false)
  $proj = $wb.VBProject

  for ($i = $proj.VBComponents.Count; $i -ge 1; $i--) {
    $c = $proj.VBComponents.Item($i)
    if ($c.Type -eq 1 -and ($c.Name -eq "Module1" -or $c.Name -eq "RGBTools")) {
      $proj.VBComponents.Remove($c)
    }
    [void][Runtime.InteropServices.Marshal]::ReleaseComObject($c)
  }

  [void]$proj.VBComponents.Import($srcBas)

  # A(Alpha) 시트 생성 및 기본값 255로 초기화 후 VeryHidden 처리
  try {
    $aSheet = $wb.Worksheets.Item("A")
  } catch {
    $aSheet = $wb.Worksheets.Add()
    $aSheet.Name = "A"
  }

  $aSheet.Range("A1:ET150").Value2 = 255
  $aSheet.Visible = 2

  try { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($aSheet) } catch {}
  $aSheet = $null

  $wb.Save()
  $wb.Close($true)

  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($proj)
  $proj = $null
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($wb)
  $wb = $null

  $excel.Quit()
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel)
  $excel = $null

  Add-RibbonXml $destBook $srcUI

  # 원래 로그인 사용자의 바탕화면에 바로가기를 만듭니다.
  $shell = New-Object -ComObject WScript.Shell
  $sc = $shell.CreateShortcut((Join-Path $TargetDesktop "RGB 체험.lnk"))
  $sc.TargetPath = $destBook
  $sc.WorkingDirectory = $destDir
  $sc.Description = "RGB 체험 리본 메뉴"
  $sc.Save()
  [void][Runtime.InteropServices.Marshal]::ReleaseComObject($shell)

  Info "설치 완료!" +
       "`n`nExcel 상단의 'RGB 체험' 탭에서" +
       "`nRGBA 이미지/투명도 기능을 사용할 수 있습니다."

  Start-Process $destBook
  exit 0
}
catch {
  $installError = $_.Exception

  try { if ($aSheet -ne $null) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($aSheet) } } catch {}
  try { if ($wb -ne $null) { $wb.Close($false) } } catch {}
  try { if ($proj -ne $null) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($proj) } } catch {}
  try { if ($wb -ne $null) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($wb) } } catch {}
  try { if ($excel -ne $null) { $excel.Quit() } } catch {}
  try { if ($excel -ne $null) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($excel) } } catch {}
  try { if ($probe -ne $null) { $probe.Quit() } } catch {}
  try { if ($probe -ne $null) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($probe) } } catch {}

  if (-not $Elevated -and (Test-PermissionError $installError)) {
    try {
      $rc = Start-ElevatedRetry $PSCommandPath $TargetLocalAppData $TargetDesktop $TargetUserSid
      exit $rc
    }
    catch {
      Fail ("관리자 권한 요청을 완료하지 못했습니다.`n`n" + $_.Exception.Message)
      exit 5
    }
  }

  if ($Elevated -and (Test-PermissionError $installError)) {
    Fail ("관리자 권한으로 다시 시도했지만 설치 권한을 확보하지 못했습니다.`n`n학교/기관 PC의 보안 정책으로 차단되었을 수 있습니다.`n`n" + $installError.Message)
    exit 4
  }

  Fail ("설치 중 오류가 발생했습니다.`n`n" + $installError.Message)
  exit 1
}
finally {
  # VBA 프로젝트 접근 설정은 원래 값으로 복원합니다.
  try {
    if ($comSec -ne $null) {
      if ($hadAccess) {
        New-ItemProperty -Path $comSec -Name AccessVBOM -PropertyType DWord -Value ([int]$oldAccess) -Force | Out-Null
      } else {
        Remove-ItemProperty -Path $comSec -Name AccessVBOM -ErrorAction SilentlyContinue
      }
    }
  } catch {}
}
