Option Explicit
Dim shell, fso, scriptDir, ps1, cmd, rc
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
ps1 = fso.BuildPath(scriptDir, "install.ps1")
If Not fso.FileExists(ps1) Then
    MsgBox "install.ps1 not found.", 16, "RGB Installer"
    WScript.Quit 1
End If
cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & ps1 & """"
rc = shell.Run(cmd, 0, True)
WScript.Quit rc
