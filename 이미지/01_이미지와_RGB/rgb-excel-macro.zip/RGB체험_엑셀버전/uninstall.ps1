﻿$ErrorActionPreference = "SilentlyContinue"
Add-Type -AssemblyName PresentationFramework

$probe = New-Object -ComObject Excel.Application
$ver = [string]$probe.Version
$probe.Quit()
[void][Runtime.InteropServices.Marshal]::ReleaseComObject($probe)

Remove-Item -Recurse -Force `
  "HKCU:\Software\Microsoft\Office\$ver\Excel\Security\Trusted Locations\Location98"

$desktop = [Environment]::GetFolderPath("Desktop")
Remove-Item -Force (Join-Path $desktop "RGB 체험.lnk")

[System.Windows.MessageBox]::Show(
  "RGB 체험의 신뢰 위치와 바로가기를 제거했습니다.",
  "RGB 체험"
) | Out-Null
